// backend/controllers/adminController.js
const Train = require('../models/Train');

const adminController = {
    addTrain: async (req, res) => {
        const { name, source, destination, total_seats } = req.body;
        try {
            const trainId = await Train.create(name, source, destination, total_seats);
            res.status(201).json({ message: 'Train added successfully', trainId });
        } catch (error) {
            res.status(500).json({ message: 'Server error' });
        }
    },

    updateSeats: async (req, res) => {
        const { trainId, total_seats } = req.body;
        try {
            await Train.updateSeats(trainId, total_seats);
            res.json({ message: 'Seats updated successfully' });
        } catch (error) {
            res.status(500).json({ message: 'Server error' });
        }
    }
};

module.exports = adminController;
