// backend/controllers/bookingController.js
const pool = require('../config/db');
const Booking = require('../models/Booking');
const Train = require('../models/Train');

const bookingController = {
    bookSeat: async (req, res) => {
        const { trainId } = req.body;
        const userId = req.user.id;

        const connection = await pool.getConnection();
        try {
            await connection.beginTransaction();

            const [rows] = await connection.execute(
                'SELECT available_seats FROM trains WHERE id = ? FOR UPDATE',
                [trainId]
            );

            if (rows.length === 0) {
                await connection.rollback();
                return res.status(404).json({ message: 'Train not found' });
            }

            const availableSeats = rows[0].available_seats;
            if (availableSeats > 0) {
                await connection.execute(
                    'UPDATE trains SET available_seats = available_seats - 1 WHERE id = ?',
                    [trainId]
                );
                const [bookingResult] = await connection.execute(
                    'INSERT INTO bookings (user_id, train_id, booking_time) VALUES (?, ?, NOW())',
                    [userId, trainId]
                );
                await connection.commit();
                res.status(200).json({ message: 'Seat booked successfully', bookingId: bookingResult.insertId });
            } else {
                await connection.rollback();
                res.status(400).json({ message: 'No seats available' });
            }
        } catch (error) {
            await connection.rollback();
            res.status(500).json({ message: 'Error booking seat' });
        } finally {
            connection.release();
        }
    },

    getBookingDetails: async (req, res) => {
        const bookingId = req.params.id;
        const userId = req.user.id;

        try {
            const booking = await Booking.findById(bookingId);
            if (!booking) {
                return res.status(404).json({ message: 'Booking not found' });
            }
            if (booking.user_id !== userId) {
                return res.status(403).json({ message: 'Forbidden' });
            }
            res.json(booking);
        } catch (error) {
            res.status(500).json({ message: 'Server error' });
        }
    }
};

module.exports = bookingController;
