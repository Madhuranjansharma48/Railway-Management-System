// backend/controllers/trainController.js
const Train = require('../models/Train');

const trainController = {
    getAvailableTrains: async (req, res) => {
        const { source, destination } = req.query;
        try {
            const trains = await Train.findAvailableTrains(source, destination);
            res.json(trains);
        } catch (error) {
            res.status(500).json({ message: 'Server error' });
        }
    }
};

module.exports = trainController;
