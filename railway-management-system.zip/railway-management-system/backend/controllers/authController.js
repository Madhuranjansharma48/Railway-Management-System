// backend/controllers/authController.js
const User = require('../models/User');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const authController = {
    register: async (req, res) => {
        const { username, password } = req.body;
        try {
            const existingUser = await User.findByUsername(username);
            if (existingUser) {
                return res.status(400).json({ message: 'User already exists' });
            }
            const userId = await User.create(username, password);
            res.status(201).json({ message: 'User registered successfully', userId });
        } catch (error) {
            res.status(500).json({ message: 'Server error' });
        }
    },

    login: async (req, res) => {
        const { username, password } = req.body;
        try {
            const user = await User.findByUsername(username);
            if (!user) {
                return res.status(400).json({ message: 'Invalid credentials' });
            }
            const validPassword = await bcrypt.compare(password, user.password_hash);
            if (!validPassword) {
                return res.status(400).json({ message: 'Invalid credentials' });
            }
            const token = jwt.sign(
                { id: user.id, username: user.username, role: user.role },
                process.env.JWT_SECRET,
                { expiresIn: '1h' }
            );
            res.json({ token });
        } catch (error) {
            res.status(500).json({ message: 'Server error' });
        }
    }
};

module.exports = authController;
