// backend/middleware/verifyAdmin.js
require('dotenv').config();

function verifyAdmin(req, res, next) {
    const apiKey = req.headers['x-api-key'];
    if (apiKey && apiKey === process.env.ADMIN_API_KEY) {
        next();
    } else {
        res.status(403).json({ message: 'Forbidden: Invalid API Key' });
    }
}

module.exports = verifyAdmin;
