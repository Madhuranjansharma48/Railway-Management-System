// backend/routes/bookingRoutes.js
const express = require('express');
const router = express.Router();
const bookingController = require('../controllers/bookingController');
const authenticateToken = require('../middleware/authenticateToken');

router.post('/book-seat', authenticateToken, bookingController.bookSeat);
router.get('/booking/:id', authenticateToken, bookingController.getBookingDetails);

module.exports = router;
