// backend/routes/trainRoutes.js
const express = require('express');
const router = express.Router();
const trainController = require('../controllers/trainController');
const authenticateToken = require('../middleware/authenticateToken');

router.get('/', authenticateToken, trainController.getAvailableTrains);

module.exports = router;
