// backend/models/Booking.js
const pool = require('../config/db');

const Booking = {
    create: async (userId, trainId) => {
        const [result] = await pool.execute(
            'INSERT INTO bookings (user_id, train_id, booking_time) VALUES (?, ?, NOW())',
            [userId, trainId]
        );
        return result.insertId;
    },

    findById: async (bookingId) => {
        const [rows] = await pool.execute(
            'SELECT * FROM bookings WHERE id = ?',
            [bookingId]
        );
        return rows[0];
    }
};

module.exports = Booking;
