// backend/models/Train.js
const pool = require('../config/db');

const Train = {
    create: async (name, source, destination, total_seats) => {
        const [result] = await pool.execute(
            'INSERT INTO trains (name, source, destination, total_seats, available_seats) VALUES (?, ?, ?, ?, ?)',
            [name, source, destination, total_seats, total_seats]
        );
        return result.insertId;
    },

    updateSeats: async (trainId, total_seats) => {
        await pool.execute(
            'UPDATE trains SET total_seats = ?, available_seats = ? WHERE id = ?',
            [total_seats, total_seats, trainId]
        );
    },

    findAvailableTrains: async (source, destination) => {
        const [rows] = await pool.execute(
            'SELECT * FROM trains WHERE source = ? AND destination = ?',
            [source, destination]
        );
        return rows;
    },

    findById: async (trainId) => {
        const [rows] = await pool.execute(
            'SELECT * FROM trains WHERE id = ?',
            [trainId]
        );
        return rows[0];
    }
};

module.exports = Train;
