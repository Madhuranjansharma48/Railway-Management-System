// dbConfig.js
const sql = require('mssql');

const config = {
    user: 'admin',
    password: 'admin_password',
    server: 'localhost',
    database: 'railway_management_system',
    options: {
        encrypt: true,
        trustServerCertificate: true
    }
};

sql.connect(config)
    .then(() => console.log('Connected to SQL Server'))
    .catch(err => console.error('Connection failed:', err));

module.exports = sql;
