import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Trains = () => {
  const [trains, setTrains] = useState([]);

  useEffect(() => {
    const fetchTrains = async () => {
      try {
        const response = await axios.get('http://localhost:3000/api/train/availability');
        setTrains(response.data);
      } catch (error) {
        console.error('Failed to fetch trains:', error);
      }
    };

    fetchTrains();
  }, []);

  return (
    <div>
      <h2>Trains</h2>
      <ul>
        {trains.map((train) => (
          <li key={train.id}>
            {train.name} - {train.availableSeats} seats available
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Trains;
