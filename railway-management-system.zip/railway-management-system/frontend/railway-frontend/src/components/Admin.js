import React, { useState } from 'react';
import axios from 'axios';

const Admin = () => {
  const [trainName, setTrainName] = useState('');
  const [availableSeats, setAvailableSeats] = useState('');
  const [source, setSource] = useState('');
  const [destination, setDestination] = useState('');

  const handleAddTrain = async () => {
    try {
      const response = await axios.post(
        'http://localhost:3000/api/train/add',
        {
          name: trainName,
          availableSeats,
          source,
          destination,
        },
        {
          headers: {
            'api-key': process.env.REACT_APP_ADMIN_API_KEY,
          },
        }
      );
      // Handle response
    } catch (error) {
      console.error('Failed to add train:', error);
    }
  };

  return (
    <div>
      <h2>Admin - Add a Train</h2>
      <input
        type="text"
        value={trainName}
        onChange={(e) => setTrainName(e.target.value)}
        placeholder="Train Name"
      />
      <input
        type="number"
        value={availableSeats}
        onChange={(e) => setAvailableSeats(e.target.value)}
        placeholder="Available Seats"
      />
      <input
        type="text"
        value={source}
        onChange={(e) => setSource(e.target.value)}
        placeholder="Source"
      />
      <input
        type="text"
        value={destination}
        onChange={(e) => setDestination(e.target.value)}
        placeholder="Destination"
      />
      <button onClick={handleAddTrain}>Add Train</button>
    </div>
  );
};

export default Admin;
