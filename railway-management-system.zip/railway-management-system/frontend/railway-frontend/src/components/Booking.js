import React, { useState } from 'react';
import axios from 'axios';

const Booking = () => {
  const [trainId, setTrainId] = useState('');
  const [seatNumber, setSeatNumber] = useState('');

  const handleBooking = async () => {
    try {
      const response = await axios.post(
        'http://localhost:3000/api/train/book',
        {
          trainId,
          seatNumber,
        },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`,
          },
        }
      );
      // Handle response
    } catch (error) {
      console.error('Booking failed:', error);
    }
  };

  return (
    <div>
      <h2>Book a Seat</h2>
      <input
        type="text"
        value={trainId}
        onChange={(e) => setTrainId(e.target.value)}
        placeholder="Train ID"
      />
      <input
        type="text"
        value={seatNumber}
        onChange={(e) => setSeatNumber(e.target.value)}
        placeholder="Seat Number"
      />
      <button onClick={handleBooking}>Book</button>
    </div>
  );
};

export default Booking;
